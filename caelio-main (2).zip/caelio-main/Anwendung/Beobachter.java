interface Beobachter
{
    public void aktualisieren(Datensatz datensatz);
}