# Caelio
Anwendung zur Überwachung von Luft-Messwerten
## Inhalt
* [Beschreibung](#beschreibung)
* [Bedienung](#bedienung)
## Beschreibung
Die Anwendung stellt eine grafische Oberfläche zur Überwachung von Luft-Messwerten bereit.
## Bedienung
Die Anwendung wird als `JavaFX Application` über die Klasse `Anwendung` im BlueJ-Projekt unter `Anwendung/package.bluej` zu starten sein.

